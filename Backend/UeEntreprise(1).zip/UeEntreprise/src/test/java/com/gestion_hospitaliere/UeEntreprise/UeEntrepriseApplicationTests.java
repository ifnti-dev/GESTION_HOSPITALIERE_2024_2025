package com.gestion_hospitaliere.UeEntreprise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UeEntrepriseApplicationTests {

	@Test
	void contextLoads() {
	}

}
