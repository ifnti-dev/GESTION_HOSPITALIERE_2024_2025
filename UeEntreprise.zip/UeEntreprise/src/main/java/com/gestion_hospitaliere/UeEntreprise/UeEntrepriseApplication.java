package com.gestion_hospitaliere.UeEntreprise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UeEntrepriseApplication {

	public static void main(String[] args) {
		SpringApplication.run(UeEntrepriseApplication.class, args);
	}

}
